export default class PlayerSheet extends ActorSheet {
	// Mandatory, where you define the path to the HTML file for your sheet.
	get template() {
		return 'systems/BlankSystem/sheets/PlayerSheet.html';
	}
}